# ionic2-app-crud
Crud Completo usando ionic 2

Ideal para estudos
#Api
utilizado APÌ desse repositorio rodando via c9.io

https://github.com/plinionaves/product-api

#Install

clone projeto

run npm install

ionic serve

# Prints
![alt tag](http://i.imgur.com/YEmgEGT.png)

![alt tag](http://i.imgur.com/cIp69q0.png)

![alt tag](http://i.imgur.com/T7ZZcVn.png)

![alt tag](http://i.imgur.com/VnOdGjx.png)
